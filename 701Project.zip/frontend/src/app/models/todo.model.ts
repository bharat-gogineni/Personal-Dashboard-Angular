export class Todo {
    _id: string;
    title: string;
    completed: boolean;
}