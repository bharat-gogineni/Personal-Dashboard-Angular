export class Task {
    _id: string;
    _listId: string;
    title: string;
    completed: boolean;
}