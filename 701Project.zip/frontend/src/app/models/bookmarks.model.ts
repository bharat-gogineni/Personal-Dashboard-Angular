export class Bookmark {
    _id: string;
    title: string;
    link: string;
}