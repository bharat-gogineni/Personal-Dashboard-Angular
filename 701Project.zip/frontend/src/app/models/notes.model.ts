export class Note {
    _id: string;
    title: string;
    text: string;
}