export class NotificationData {
    text: string
    duration: number
}