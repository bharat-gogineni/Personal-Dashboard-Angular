Setup steps
Run `npm install` on both front end api folder
run `node mongoose.js` inside "api/db/" folder
then run `node app.js` inside "api" folder 
Run `ng-serve` inside frontend folder

Open application at `http://localhost:4200`

Sign up with a user before trying to login